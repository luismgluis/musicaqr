"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const selenium_webdriver_1 = require("selenium-webdriver");
const TAG = "SELENIUM ACTIONS";
class SeleniumActions {
    constructor(app) {
        this.app = app;
        this.lastUrlNavigated = "";
    }
    clean() {
        this.lastUrlNavigated = "";
    }
    querySelector(domElement) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = this.app.browserDriver;
            const exe = yield selenium_webdriver_1.By.js(domElement)(driver)
                .then((data) => data)
                .catch((err) => null);
            return exe;
        });
    }
    navigate(url) {
        return __awaiter(this, void 0, void 0, function* () {
            const that = this;
            if (url === that.lastUrlNavigated)
                return true;
            const driver = that.app.browserDriver;
            yield driver.switchTo().newWindow("tab");
            const tabs = yield driver.getAllWindowHandles();
            if (tabs.length > 1) {
                console.log(tabs);
                yield driver.switchTo().window(tabs[0]);
                yield driver.close();
                yield driver.switchTo().window(tabs[1]);
            }
            const res = yield driver
                .get(url)
                .then(() => {
                console.log(TAG, "driver get");
                return true;
            })
                .catch((err) => {
                return false;
            })
                .finally(() => {
                that.lastUrlNavigated = url;
            });
            return res;
        });
    }
    awaitLoading(domElement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const driver = this.app.browserDriver;
                if (domElement) {
                    yield driver.wait(() => __awaiter(this, void 0, void 0, function* () {
                        const element = yield this.querySelector(domElement);
                        if (element) {
                            return true;
                        }
                        return false;
                    }), 300);
                    console.log("ready");
                }
                else {
                    yield driver.sleep(200);
                }
            }
            catch (error) {
                console.log(error);
            }
            return true;
        });
    }
    awaitRemove(domElement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const driver = this.app.browserDriver;
                if (domElement) {
                    yield driver.wait(() => __awaiter(this, void 0, void 0, function* () {
                        const element = yield this.querySelector(domElement);
                        if (element) {
                            return false;
                        }
                        return true;
                    }), 300);
                    console.log("ready");
                }
                else {
                    yield driver.sleep(200);
                }
            }
            catch (error) {
                console.log(error);
            }
            return true;
        });
    }
    click(domElement) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const element = yield this.querySelector(domElement);
                yield element.click();
                return true;
            }
            catch (error) {
                return false;
            }
        });
    }
    setInputValue(domElement, value) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = this.app.browserDriver;
            const element = yield this.querySelector(domElement);
            // driver.findElement(element)
            yield element.clear();
            const result = yield element
                .sendKeys(value)
                .then(() => __awaiter(this, void 0, void 0, function* () {
                yield driver.sleep(200);
                return true;
            }))
                .catch((err) => {
                console.log(err);
                return false;
            });
            return result;
        });
    }
    getInputValue(domElement) {
        return __awaiter(this, void 0, void 0, function* () {
            const element = yield this.querySelector(domElement);
            //driver.findElement(element)
            const result = element
                .getText() //"admin\n")
                .then((data) => {
                return data;
            })
                .catch((err) => {
                return null;
            });
            return result;
        });
    }
    changeFrame(frameElement) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = this.app.browserDriver;
            const frame = yield this.querySelector(frameElement);
            yield driver.switchTo().frame(frameElement === "null" ? null : frame);
            return true;
        });
    }
    execute(action, scriptSearchElement, value = "") {
        return __awaiter(this, void 0, void 0, function* () {
            let result = { state: false, value: null };
            const driver = this.app.browserDriver;
            switch (action) {
                case "navigate":
                    result.state = yield this.navigate(value);
                    break;
                case "click":
                    result.state = yield this.click(scriptSearchElement);
                    break;
                case "await":
                    result.state = yield this.awaitLoading(scriptSearchElement);
                    break;
                case "setInputValue":
                    result.state = yield this.setInputValue(scriptSearchElement, value);
                    break;
                case "getInputValue":
                    result.state = yield this.getInputValue(scriptSearchElement);
                    break;
                case "awaitRemove":
                    result.state = yield this.awaitRemove(scriptSearchElement);
                    break;
                case "searchElement":
                    const el = yield this.querySelector(scriptSearchElement);
                    if (el) {
                        result.state = true;
                        result.value = el;
                    }
                    break;
                case "changeFrame":
                    result.state = yield this.changeFrame(scriptSearchElement);
                    break;
                default:
                    break;
            }
            yield driver.sleep(500);
            return result;
        });
    }
}
exports.default = SeleniumActions;
//# sourceMappingURL=seleniumActions.js.map