"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
   
   
   assignable to parameter of type 'FireDoc'.
  Property 'createTime' is optional in type 'DocumentSnapshot<DocumentData>' but required in type 'QueryDocumentSnapshot<DocumentData>

   */
//# sourceMappingURL=types.js.map